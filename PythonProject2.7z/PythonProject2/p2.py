# name="Vanya"
# userName = "Vanya"
# user_name = "Vanya"
# print(name)
# name="jadsa"
# print(name)
# myNumber=input()
# print(myNumber)
# myAge=input("Введите свой возраст")
# print("Ваш возраст",myAge)
# isGood=True
# print(isGood)
# isAlive = False
# print(isAlive)
# myAge = 16
# print("Возраст", myAge)
# myCount = 3312312312321312
# print("Количество", myCount)
# myNumberOne = 0b10010101010101010
# myNumberTwo = 0o72647274167
# myNumberThree = 0x273FFAB
# print(myNumberOne,myNumberTwo,myNumberThree)
# myHeight = 2.50
# weight = 109.6
# print(myHeight,weight)
# hello = "Hello World"
# print(hello)
# ya = "Привет я ваня мне 16"
import math

a = int (input("Введите значение переменной"))
z1 = 1-1/4*math.sin(2*a)**2 + math.cos(2*a)
z2 = math.cos(a)**2 + math.cos(a)**4
print(z1)
print(z2)