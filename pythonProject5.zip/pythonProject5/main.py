# import math
# a = int(input())
# print(math.factorial(a))
# import random
# a = random.randint(0,100)
# print("Загадано число от 0 до 100. У тебя 10 попыток чтобы угадать)")
# x = 0
# while x < 10:
#     b = int(input())
#     x = x+1
#     if b == a:
#         print(f"Угадал")
#     else:
#         print(f"Не угадал")
# print(f"Ты не угадал. Число было {a}")

# a = int(input("Минимум"))
# b = int(input("Максимум"))
# c = int(input("Шаг"))
# while a < b:
#     a= a+c
#     print(f"Число{a}")








