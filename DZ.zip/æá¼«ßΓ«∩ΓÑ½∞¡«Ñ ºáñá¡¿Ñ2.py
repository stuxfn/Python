import math
print('Введите x,y,z,e')
x=float(input())
y=float(input())
z=float(input())
e=float(input())
u=((8+abs((x-y)**2)+1)**1/3)/x**2+y**2+2-e**abs(x-y)*(math.tan(z)**2+1)**2
print('u=',u)
input()