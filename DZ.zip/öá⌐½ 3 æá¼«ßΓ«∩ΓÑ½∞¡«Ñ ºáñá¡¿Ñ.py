import math
print('Введите x,y,z,e')
try:
    x=float(input())
except ValueError:
    print('Напишите число')
    x=float(input())
try:
    y=float(input())
except ValueError:
    print('Напишите число')
    y=float(input())
try:
    z=float(input())
except ValueError:
    print('Напишите число')
    z=float(input())
try:
    e=float(input())
except ValueError:
    print('Напишите число')
    e=float(input())
u=((8+abs((x-y)**2)+1)**1/3)/x**2+y**2+2-e**abs(x-y)*(math.tan(z)**2+1)**2
if math.tan != range (-1,1): print('Допустимое значение')
print('u=',u)
input()