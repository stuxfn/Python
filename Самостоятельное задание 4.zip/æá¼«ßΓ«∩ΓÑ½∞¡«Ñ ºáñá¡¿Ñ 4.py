import math

a = 4
b = 8
n = 15
h = (b-a)/n
while a < b:
    F = (a**2-4*a+8)/math.sin(6*a)
    print(f"a={a} F={F}")
    a = a+h