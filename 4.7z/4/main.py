# import math
#
# a = float(0.7)
# b = float(1.8)
# h = float(0.1)
# while a < b:
#         y= math.log10(abs(2*math.sin(a/2)))
#         print(f"a={a} y={y}")
#         a= a+h
# import math
# a= float(-2)
# b= float(0.8)
# h= float(0.2)
# while a<b:
#     y= (a*math.cos(math.pi/4))/(1-2*a*math.cos(math.pi/4)+a**2)
#     print(f"a={a} y={y}")
#     a= a+h
import math
a = 0.1
b = 1.0
h = 0.1
x=0
 while a < b:
     s = (math.cos(k*a)) / (math.factorial(k))





